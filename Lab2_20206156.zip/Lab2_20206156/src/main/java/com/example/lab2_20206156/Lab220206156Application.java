package com.example.lab2_20206156;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab220206156Application {

	public static void main(String[] args) {
		SpringApplication.run(Lab220206156Application.class, args);
	}

}
