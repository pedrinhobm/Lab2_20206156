package com.example.lab2_20206156;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab220206156ApplicationTests {

	@Test
	void contextLoads() {
	}

}
